import { db } from "@/db";
import { tasks } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const rows = await db.select().from(tasks).where(eq(tasks.id, Number(id)));
    if (!rows[0]) return Response.json({ error: "Not found" }, { status: 404 });
    return Response.json({ task: rows[0] });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const patch: Partial<typeof tasks.$inferInsert> = {};
    if (body.status) {
      patch.status = String(body.status);
      if (["completed", "failed", "cancelled"].includes(patch.status)) {
        patch.completedAt = new Date();
      }
    }
    if (body.result !== undefined) patch.result = String(body.result);
    const rows = await db.update(tasks).set(patch).where(eq(tasks.id, Number(id))).returning();
    return Response.json({ task: rows[0] });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
