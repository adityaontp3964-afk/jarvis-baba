import { db } from "@/db";
import { quickActions } from "@/db/schema";
import { asc } from "drizzle-orm";
import { DEFAULT_QUICK_ACTIONS } from "@/lib/jarvis-brain";

export const dynamic = "force-dynamic";

async function ensureSeed() {
  const rows = await db.select().from(quickActions);
  if (rows.length === 0) {
    for (let i = 0; i < DEFAULT_QUICK_ACTIONS.length; i++) {
      const qa = DEFAULT_QUICK_ACTIONS[i];
      await db.insert(quickActions).values({
        actionKey: qa.actionKey,
        label: qa.label,
        icon: qa.icon,
        enabled: true,
        sortOrder: i,
      });
    }
  }
}

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.select().from(quickActions).orderBy(asc(quickActions.sortOrder));
    return Response.json({ actions: rows });
  } catch (e) {
    return Response.json({ actions: [], error: String(e) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const list = body.actions as { actionKey: string; enabled: boolean; label?: string }[];
    if (Array.isArray(list)) {
      const { eq } = await import("drizzle-orm");
      for (let i = 0; i < list.length; i++) {
        const a = list[i];
        await db
          .update(quickActions)
          .set({ enabled: Boolean(a.enabled), label: a.label ?? undefined, sortOrder: i })
          .where(eq(quickActions.actionKey, a.actionKey));
      }
    }
    const rows = await db.select().from(quickActions).orderBy(asc(quickActions.sortOrder));
    return Response.json({ actions: rows });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
