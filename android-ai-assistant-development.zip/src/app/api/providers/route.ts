import { db } from "@/db";
import { providers } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

function maskKey(k: string) {
  if (!k) return "";
  if (k.length <= 8) return "••••";
  return k.slice(0, 4) + "••••" + k.slice(-4);
}

export async function GET() {
  try {
    const rows = await db.select().from(providers).orderBy(desc(providers.createdAt));
    const safe = rows.map((r) => ({ ...r, apiKey: "", apiKeyMasked: maskKey(r.apiKey) }));
    return Response.json({ providers: safe });
  } catch (e) {
    return Response.json({ providers: [], error: String(e) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, type, baseUrl, model, apiKey, isActive } = body;
    if (!name || !model) {
      return Response.json({ error: "Name and model are required" }, { status: 400 });
    }
    if (isActive) {
      const { eq } = await import("drizzle-orm");
      await db.update(providers).set({ isActive: false }).where(eq(providers.isActive, true));
    }
    const inserted = await db
      .insert(providers)
      .values({
        name: String(name).slice(0, 120),
        type: String(type || "groq").slice(0, 40),
        baseUrl: String(baseUrl || ""),
        model: String(model).slice(0, 200),
        apiKey: String(apiKey || ""),
        isActive: Boolean(isActive),
      })
      .returning();
    const row = inserted[0];
    return Response.json({
      provider: { ...row, apiKey: "", apiKeyMasked: maskKey(row.apiKey) },
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
