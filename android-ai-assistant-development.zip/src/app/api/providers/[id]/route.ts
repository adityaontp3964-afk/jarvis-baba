import { db } from "@/db";
import { providers } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

function maskKey(k: string) {
  if (!k) return "";
  if (k.length <= 8) return "••••";
  return k.slice(0, 4) + "••••" + k.slice(-4);
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const patch: Partial<typeof providers.$inferInsert> = {};
    if (body.name !== undefined) patch.name = String(body.name).slice(0, 120);
    if (body.type !== undefined) patch.type = String(body.type).slice(0, 40);
    if (body.baseUrl !== undefined) patch.baseUrl = String(body.baseUrl);
    if (body.model !== undefined) patch.model = String(body.model).slice(0, 200);
    if (body.apiKey !== undefined && String(body.apiKey).length > 0) patch.apiKey = String(body.apiKey);
    if (body.isActive !== undefined) patch.isActive = Boolean(body.isActive);
    if (body.lastTestOk !== undefined) {
      patch.lastTestOk = Boolean(body.lastTestOk);
      patch.lastTestedAt = new Date();
    }
    if (patch.isActive) {
      await db.update(providers).set({ isActive: false }).where(eq(providers.isActive, true));
    }
    const rows = await db
      .update(providers)
      .set(patch)
      .where(eq(providers.id, Number(id)))
      .returning();
    if (!rows[0]) return Response.json({ error: "Not found" }, { status: 404 });
    return Response.json({
      provider: { ...rows[0], apiKey: "", apiKeyMasked: maskKey(rows[0].apiKey) },
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    await db.delete(providers).where(eq(providers.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
