import { db } from "@/db";
import { deviceModels } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { OFFLINE_LLM_CATALOG, VOICE_CATALOG } from "@/lib/jarvis-brain";

export const dynamic = "force-dynamic";

async function ensureSeed() {
  const rows = await db.select().from(deviceModels);
  if (rows.length === 0) {
    for (const m of OFFLINE_LLM_CATALOG) {
      await db.insert(deviceModels).values({
        kind: "llm",
        name: m.name,
        description: m.description,
        sizeMb: m.sizeMb,
        downloadUrl: m.downloadUrl,
        status: "available",
        progress: 0,
        isActive: false,
      });
    }
    for (const m of VOICE_CATALOG) {
      const kind = m.name.includes("TTS") || m.name.toLowerCase().includes("piper") ? "tts" : "stt";
      await db.insert(deviceModels).values({
        kind,
        name: m.name,
        description: m.description,
        sizeMb: m.sizeMb,
        downloadUrl: m.downloadUrl,
        status: "available",
        progress: 0,
        isActive: false,
      });
    }
  }
}

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.select().from(deviceModels).orderBy(asc(deviceModels.id));
    return Response.json({ models: rows });
  } catch (e) {
    return Response.json({ models: [], error: String(e) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { action, id } = body as { action: string; id: number };
    if (!id) return Response.json({ error: "id required" }, { status: 400 });
    if (action === "download") {
      await db.update(deviceModels).set({ status: "downloading", progress: 5 }).where(eq(deviceModels.id, Number(id)));
      return Response.json({ ok: true, status: "downloading" });
    }
    if (action === "progress") {
      const rows = await db.select().from(deviceModels).where(eq(deviceModels.id, Number(id)));
      const cur = rows[0];
      if (!cur) return Response.json({ error: "not found" }, { status: 404 });
      const next = Math.min(100, (cur.progress ?? 0) + 18);
      const done = next >= 100;
      await db
        .update(deviceModels)
        .set({ progress: next, status: done ? "installed" : "downloading" })
        .where(eq(deviceModels.id, Number(id)));
      return Response.json({ ok: true, progress: next, status: done ? "installed" : "downloading" });
    }
    if (action === "activate") {
      const rows = await db.select().from(deviceModels).where(eq(deviceModels.id, Number(id)));
      const cur = rows[0];
      if (cur) {
        await db.update(deviceModels).set({ isActive: false }).where(eq(deviceModels.kind, cur.kind));
        await db.update(deviceModels).set({ isActive: true }).where(eq(deviceModels.id, Number(id)));
      }
      return Response.json({ ok: true });
    }
    if (action === "delete") {
      await db
        .update(deviceModels)
        .set({ status: "available", progress: 0, isActive: false })
        .where(eq(deviceModels.id, Number(id)));
      return Response.json({ ok: true });
    }
    return Response.json({ error: "unknown action" }, { status: 400 });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
