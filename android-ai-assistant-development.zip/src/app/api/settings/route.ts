import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { DEFAULT_SETTINGS } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(appSettings);
    const merged: Record<string, unknown> = { ...(DEFAULT_SETTINGS as unknown as Record<string, unknown>) };
    for (const r of rows) {
      merged[r.key] = r.value as unknown;
    }
    // flatten: if stored as {settings: {...}} support legacy
    return Response.json({ settings: merged });
  } catch (e) {
    return Response.json({ settings: DEFAULT_SETTINGS, error: String(e) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const settings = body.settings || body;
    for (const [k, v] of Object.entries(settings)) {
      await db
        .insert(appSettings)
        .values({ key: k, value: v as object, updatedAt: new Date() })
        .onConflictDoUpdate({ target: appSettings.key, set: { value: v as object, updatedAt: new Date() } });
    }
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
