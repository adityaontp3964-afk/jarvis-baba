export type JarvisMode = "auto" | "online" | "offline";

export type IntentType =
  | "open_app"
  | "web_search"
  | "youtube_search"
  | "phone_call"
  | "whatsapp_message"
  | "set_alarm"
  | "open_settings"
  | "volume_control"
  | "navigate_back"
  | "navigate_home"
  | "scroll"
  | "type_text"
  | "conversation"
  | "unknown";

export interface ParsedIntent {
  intent: IntentType;
  confidence: number;
  entities: Record<string, string>;
  steps: string[];
  needsClarification: boolean;
  clarification?: string;
  actionLabel: string;
  webUrl?: string;
  androidIntent?: string;
  requiresConfirmation?: boolean;
  language: "en" | "hi" | "hinglish";
}

export function detectLanguage(input: string): "en" | "hi" | "hinglish" {
  if (/[\u0900-\u097F]/.test(input)) {
    const hasEnglish = /[a-zA-Z]{3,}/.test(input);
    return hasEnglish ? "hinglish" : "hi";
  }
  const hinglishWords =
    /\b(kholo|khol|karo|kar|do|bhejo|kaise|kya|hai|hain|mein|par|ko|se|ke|ki|ka|nahi|nahin|achha|acha|batao|dikhao|chalao|lagao|bajao|sunao|milte|kal|aaj)\b/i;
  if (hinglishWords.test(input)) return "hinglish";
  return "en";
}

const APP_MAP: Record<string, { label: string; pkg: string; web: string }> = {
  whatsapp: {
    label: "WhatsApp",
    pkg: "com.whatsapp",
    web: "https://wa.me/",
  },
  youtube: {
    label: "YouTube",
    pkg: "com.google.android.youtube",
    web: "https://www.youtube.com",
  },
  chrome: {
    label: "Chrome",
    pkg: "com.android.chrome",
    web: "https://www.google.com",
  },
  gmail: { label: "Gmail", pkg: "com.google.android.gm", web: "https://mail.google.com" },
  maps: { label: "Maps", pkg: "com.google.android.apps.maps", web: "https://maps.google.com" },
  camera: { label: "Camera", pkg: "com.android.camera", web: "" },
  gallery: { label: "Gallery", pkg: "com.android.gallery", web: "" },
  settings: { label: "Settings", pkg: "com.android.settings", web: "" },
  phone: { label: "Phone", pkg: "com.android.dialer", web: "" },
  clock: { label: "Clock", pkg: "com.android.deskclock", web: "" },
  spotify: {
    label: "Spotify",
    pkg: "com.spotify.music",
    web: "https://open.spotify.com",
  },
  instagram: {
    label: "Instagram",
    pkg: "com.instagram.android",
    web: "https://www.instagram.com",
  },
};

export function parseIntent(
  rawInput: string,
  context?: { lastApp?: string; lastQuery?: string; pending?: ParsedIntent | null }
): ParsedIntent {
  const input = rawInput.trim();
  const lower = input.toLowerCase();
  const language = detectLanguage(input);

  const t = (en: string, hinglish: string, hi: string) =>
    language === "hi" ? hi : language === "hinglish" ? hinglish : en;

  // navigate back
  if (
    /\b(back jao|back|peeche jao|wapas jao|go back)\b/i.test(lower) &&
    lower.length < 40
  ) {
    return {
      intent: "navigate_back",
      confidence: 0.95,
      entities: {},
      steps: ["Validate accessibility permission", "Execute Back action"],
      needsClarification: false,
      actionLabel: "Navigate Back",
      androidIntent: "ACCESSIBILITY_ACTION_BACK",
      language,
    };
  }
  if (/\b(home screen|home par|home jao|go home)\b/i.test(lower) && lower.length < 50) {
    return {
      intent: "navigate_home",
      confidence: 0.95,
      entities: {},
      steps: ["Validate permission", "Execute Home action"],
      needsClarification: false,
      actionLabel: "Go Home",
      androidIntent: "Intent.ACTION_MAIN + CATEGORY_HOME",
      language,
    };
  }
  // scroll
  if (/\b(scroll|neeche scroll|upar scroll|scroll karo)\b/i.test(lower)) {
    const dir = /upar|up\b/i.test(lower) ? "up" : "down";
    return {
      intent: "scroll",
      confidence: 0.9,
      entities: { direction: dir },
      steps: ["Find scrollable node", `Scroll ${dir} via accessibility`],
      needsClarification: false,
      actionLabel: `Scroll ${dir}`,
      androidIntent: "ACCESSIBILITY_ACTION_SCROLL",
      language,
    };
  }
  // volume
  const volMatch = lower.match(/volume\s*(\d{1,3})?\s*(percent|%)?/i);
  if (/\b(volume|aawaz|awaz|sound)\b/i.test(lower)) {
    const pct = volMatch?.[1] ?? "";
    if (!pct && /\b(volume|aawaz)\b/.test(lower) && lower.length < 60 && !/search|open/i.test(lower)) {
      return {
        intent: "volume_control",
        confidence: 0.7,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "What volume level should I set? For example: volume 50 percent.",
          "Volume kitna karun? Jaise bolo: volume 50 percent kar do.",
          "वॉल्यूम कितना करूँ? जैसे बोलें: वॉल्यूम 50 प्रतिशत कर दो।"
        ),
        actionLabel: "Volume control",
        language,
      };
    }
    return {
      intent: "volume_control",
      confidence: 0.92,
      entities: { level: pct || "50" },
      steps: ["Check audio permission", `Set media volume to ${pct || "50"}%`],
      needsClarification: false,
      actionLabel: `Set volume ${pct || "50"}%`,
      androidIntent: "AudioManager.setStreamVolume",
      language,
    };
  }
  // whatsapp
  if (/whatsapp/i.test(lower)) {
    const contactMatch = input.match(
      /(?:ko|to)\s+(?:whatsapp\s+)?(?:message|msg|message bhejo|bhejo)?\s*$/i
    );
    // extract contact: e.g. "Rahul ko WhatsApp message bhejo" or "WhatsApp par Rahul ko ..."
    let contact = "";
    const m1 = input.match(/([A-ZÀ-ÿa-z\u0900-\u097F]+)\s+ko\s+whatsapp/i);
    const m2 = input.match(/whatsapp\s+(?:par\s+)?([A-ZÀ-ÿa-z\u0900-\u097F]+)\s+ko/i);
    const m3 = input.match(/message\s+bhejo\s+([A-ZÀ-ÿa-z\u0900-\u097F]+)/i);
    contact = (m1?.[1] || m2?.[1] || m3?.[1] || "").trim();
    // message extraction after colon or quote
    let message = "";
    const qm = input.match(/["“”'](.+?)["“”']/);
    if (qm) message = qm[1];
    const colonMsg = input.match(/message\s*[:\-]\s*(.+)/i);
    if (!message && colonMsg) message = colonMsg[1].trim();

    if (!contact) {
      return {
        intent: "whatsapp_message",
        confidence: 0.85,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "Who should I send the WhatsApp message to? For example: Send WhatsApp message to Rahul.",
          "Kisko WhatsApp message bhejna hai? Jaise bolo: Rahul ko WhatsApp message bhejo.",
          "किसे WhatsApp संदेश भेजना है? जैसे बोलें: राहुल को WhatsApp संदेश भेजो।"
        ),
        actionLabel: "WhatsApp message",
        language,
      };
    }
    if (!message) {
      return {
        intent: "whatsapp_message",
        confidence: 0.88,
        entities: { contact },
        steps: [`Resolve contact "${contact}"`, "Await message text", "Draft + confirm before send"],
        needsClarification: true,
        clarification: t(
          `What message should I send to ${contact}? I will show it for confirmation and only send after you confirm.`,
          `${contact} ko kaunsa message bhejna hai? Main draft dikhaunga aur aapke confirm karne par hi bhejunga. Exact wording batao.`,
          `${contact} को कौन-सा संदेश भेजना है? मैं ड्राफ्ट दिखाऊँगा और आपके कन्फर्म करने पर ही भेजूँगा।`
        ),
        actionLabel: `WhatsApp to ${contact}`,
        language,
      };
    }
    return {
      intent: "whatsapp_message",
      confidence: 0.95,
      entities: { contact, message },
      steps: [
        `Resolve contact "${contact}"`,
        "Open WhatsApp conversation via intent",
        `Draft exact message (preserved verbatim)`,
        "Await explicit user confirmation",
        "Send via accessibility-confirmed action",
      ],
      needsClarification: false,
      actionLabel: `WhatsApp to ${contact}`,
      webUrl: `https://wa.me/?text=${encodeURIComponent(message)}`,
      androidIntent: "Intent.ACTION_VIEW wa.me + Accessibility TYPE",
      requiresConfirmation: true,
      language,
    };
  }
  // phone call: "call Rahul", "Rahul ko call karo"
  const callMatch = lower.match(/(?:call|phone|call karo|call lagao)\s*([a-z\u0900-\u097F ]+)?/i);
  if (/\b(call|phone karo|call lagao|call karo)\b/i.test(lower)) {
    let contact = "";
    const c1 = input.match(/([A-Za-z\u0900-\u097F]+)\s+ko\s+call/i);
    const c2 = input.match(/call\s+(?:karo\s+)?([A-Za-z\u0900-\u097F]+)/i);
    contact = (c1?.[1] || c2?.[1] || "").replace(/karo|lagao|please/gi, "").trim();
    if (!contact || contact.length < 2) {
      return {
        intent: "phone_call",
        confidence: 0.8,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "Who should I call?",
          "Kisko call karna hai? Naam batao.",
          "किसे कॉल करना है?"
        ),
        actionLabel: "Phone call",
        language,
      };
    }
    return {
      intent: "phone_call",
      confidence: 0.9,
      entities: { contact },
      steps: [`Resolve contact "${contact}"`, "Request confirmation", "Place call via ACTION_CALL"],
      needsClarification: false,
      actionLabel: `Call ${contact}`,
      androidIntent: "Intent.ACTION_CALL (requires CALL_PHONE + confirmation)",
      requiresConfirmation: true,
      language,
    };
  }
  // open app: "open YouTube", "YouTube kholo", "Chrome open karo"
  for (const key of Object.keys(APP_MAP)) {
    const re = new RegExp(`\\b${key}\\b`, "i");
    if (re.test(lower) && /(open|kholo|khol|start|launch|chalao|open karo)/i.test(lower)) {
      const app = APP_MAP[key];
      // check follow-up search? e.g. "YouTube kholo" simple
      return {
        intent: "open_app",
        confidence: 0.94,
        entities: { app: key, label: app.label },
        steps: [`Resolve package ${app.pkg}`, "Launch via PackageManager intent", "Verify foreground app"],
        needsClarification: false,
        actionLabel: `Open ${app.label}`,
        webUrl: app.web || undefined,
        androidIntent: `getLaunchIntentForPackage(${app.pkg})`,
        language,
      };
    }
  }
  // generic open settings
  if (/\b(settings|setting kholo|setting open)\b/i.test(lower)) {
    return {
      intent: "open_settings",
      confidence: 0.92,
      entities: {},
      steps: ["Open system settings via intent"],
      needsClarification: false,
      actionLabel: "Open Settings",
      androidIntent: "Settings.ACTION_SETTINGS",
      language,
    };
  }
  // set alarm: "set alarm", "alarm lagao 7 baje"
  if (/\b(alarm|alram)\b/i.test(lower)) {
    const timeMatch = input.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje)?/i);
    if (!timeMatch) {
      return {
        intent: "set_alarm",
        confidence: 0.82,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "What time should I set the alarm for? For example: set alarm for 7 AM.",
          "Alarm kitne baje lagana hai? Jaise bolo: subah 7 baje alarm lagao.",
          "अलार्म कितने बजे लगाना है?"
        ),
        actionLabel: "Set alarm",
        language,
      };
    }
    return {
      intent: "set_alarm",
      confidence: 0.9,
      entities: { time: timeMatch[0] },
      steps: ["Parse time", "Create alarm via AlarmClock intent", "Verify"],
      needsClarification: false,
      actionLabel: `Set alarm ${timeMatch[0]}`,
      androidIntent: "AlarmClock.ACTION_SET_ALARM",
      language,
    };
  }
  // youtube search: "Arijit Singh songs search karo", "YouTube par ... search"
  if (
    /youtube/i.test(lower) ||
    (/(search karo|search kar|search|play|bajao|sunao|song|video)/i.test(lower) &&
      (context?.lastApp === "youtube" || /pehla result|first result/i.test(lower) === false))
  ) {
    // "Ab Arijit Singh search karo" with context
    if (
      /(search karo|search|play|bajao|sunao)/i.test(lower) &&
      (context?.lastApp === "youtube" || /youtube|video|song|play/i.test(lower))
    ) {
      let query = input
        .replace(/ab\s+/i, "")
        .replace(/youtube\s*(par|pe|mein|kholo)?/gi, "")
        .replace(/(search karo|search kar|search|play karo|bajao|sunao|video|song)/gi, "")
        .replace(/(kholo|khol|open)/gi, "")
        .trim();
      if (!query && context?.lastQuery) query = context.lastQuery;
      if (!query || query.length < 2) {
        return {
          intent: "youtube_search",
          confidence: 0.8,
          entities: {},
          steps: [],
          needsClarification: true,
          clarification: t(
            "What should I search on YouTube?",
            "YouTube par kya search karun?",
            "YouTube पर क्या सर्च करूँ?"
          ),
          actionLabel: "YouTube search",
          language,
        };
      }
      return {
        intent: "youtube_search",
        confidence: 0.93,
        entities: { query },
        steps: [
          "Ensure YouTube is open",
          `Search YouTube for "${query}"`,
          "Show results for selection",
        ],
        needsClarification: false,
        actionLabel: `YouTube: ${query}`,
        webUrl: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,
        androidIntent: "YouTube search intent + Accessibility",
        language,
      };
    }
  }
  // "pehla result open karo" / follow-up open first result
  if (/(pehla|first)\s+(result|video|wala).*open/i.test(lower) || (/open.*(first|pehla)/i.test(lower))) {
    const q = context?.lastQuery || "result";
    return {
      intent: "youtube_search",
      confidence: 0.88,
      entities: { query: q, openFirst: "true" },
      steps: ["Identify first result", "Open first result", "Verify playback screen"],
      needsClarification: false,
      actionLabel: `Open first result: ${q}`,
      webUrl: context?.lastQuery
        ? `https://www.youtube.com/results?search_query=${encodeURIComponent(context.lastQuery)}`
        : "https://www.youtube.com",
      androidIntent: "Accessibility click first result",
      language,
    };
  }
  // type text: "ye text type karo: ..."
  if (/\b(type karo|type kar|type this|likho)\b/i.test(lower)) {
    const textMatch = input.match(/[:\-"“”']\s*(.+)$/);
    const toType = textMatch?.[1]?.trim() || "";
    if (!toType) {
      return {
        intent: "type_text",
        confidence: 0.8,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "What text should I type? Please dictate the exact text.",
          "Kaunsa text type karna hai? Exact text batao.",
          "कौन-सा टेक्स्ट टाइप करना है?"
        ),
        actionLabel: "Type text",
        language,
      };
    }
    return {
      intent: "type_text",
      confidence: 0.9,
      entities: { text: toType },
      steps: ["Focus input field", "Type via accessibility input", "Verify text"],
      needsClarification: false,
      actionLabel: "Type text",
      androidIntent: "AccessibilityNodeInfo.ACTION_SET_TEXT",
      language,
    };
  }
  // web search: "Google par search karo ...", "search ..."
  if (/\b(search karo|search kar|google|search|dhundo|khojo)\b/i.test(lower)) {
    let query = input
      .replace(/google\s*(par|pe|mein)?/gi, "")
      .replace(/(par\s+)?search\s*(karo|kar)?/gi, "")
      .replace(/^(jarvis[,\s]*)/i, "")
      .replace(/^(please\s+)/i, "")
      .trim();
    if (query.length < 2) {
      return {
        intent: "web_search",
        confidence: 0.8,
        entities: {},
        steps: [],
        needsClarification: true,
        clarification: t(
          "What should I search for?",
          "Kya search karna hai? Batao.",
          "क्या सर्च करना है?"
        ),
        actionLabel: "Web search",
        language,
      };
    }
    return {
      intent: "web_search",
      confidence: 0.9,
      entities: { query },
      steps: [`Web search for "${query}"`],
      needsClarification: false,
      actionLabel: `Search: ${query}`,
      webUrl: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      androidIntent: "Intent.ACTION_VIEW browser",
      language,
    };
  }
  // greetings / capabilities / conversation
  if (/^(hi|hello|hey|namaste|sat sri|ram ram|jarvis)\b/i.test(lower) && lower.length < 30) {
    return {
      intent: "conversation",
      confidence: 0.9,
      entities: {},
      steps: ["Greet"],
      needsClarification: false,
      actionLabel: "Greeting",
      language,
    };
  }

  // default: conversation (will go to online LLM if available, else offline chat)
  return {
    intent: "conversation",
    confidence: 0.6,
    entities: { raw: input },
    steps: ["Understand", "Respond"],
    needsClarification: false,
    actionLabel: "Chat",
    language,
  };
}

export function offlineReply(input: string, parsed: ParsedIntent): string {
  const lang = parsed.language;
  const t = (en: string, hinglish: string, hi: string) =>
    lang === "hi" ? hi : lang === "hinglish" ? hinglish : en;

  switch (parsed.intent) {
    case "open_app":
      return t(
        `Opening ${parsed.entities.label}. Done — verified on-device.`,
        `${parsed.entities.label} khol raha hun. Ho gaya, sir.`,
        `${parsed.entities.label} खोल रहा हूँ। हो गया।`
      );
    case "youtube_search":
      if (parsed.entities.openFirst)
        return t(
          `Opening the first result for "${parsed.entities.query}".`,
          `"${parsed.entities.query}" ka pehla result open kar raha hun.`,
          `"${parsed.entities.query}" का पहला परिणाम खोल रहा हूँ।`
        );
      return t(
        `Searching YouTube for "${parsed.entities.query}". Showing results now.`,
        `YouTube par "${parsed.entities.query}" search kar raha hun. Results dikha raha hun.`,
        `YouTube पर "${parsed.entities.query}" सर्च कर रहा हूँ।`
      );
    case "web_search":
      return t(
        `Searching the web for "${parsed.entities.query}".`,
        `"${parsed.entities.query}" web par search kar raha hun.`,
        `"${parsed.entities.query}" वेब पर सर्च कर रहा हूँ।`
      );
    case "volume_control":
      return t(
        `Volume set to ${parsed.entities.level} percent.`,
        `Volume ${parsed.entities.level} percent kar diya, sir.`,
        `वॉल्यूम ${parsed.entities.level} प्रतिशत कर दिया।`
      );
    case "navigate_back":
      return t(`Going back.`, `Back ja raha hun.`, `वापस जा रहा हूँ।`);
    case "navigate_home":
      return t(`Going to home screen.`, `Home screen par ja raha hun.`, `होम स्क्रीन पर जा रहा हूँ।`);
    case "scroll":
      return t(
        `Scrolling ${parsed.entities.direction}.`,
        `${parsed.entities.direction === "up" ? "Upar" : "Neeche"} scroll kar raha hun.`,
        `स्क्रॉल कर रहा हूँ।`
      );
    case "set_alarm":
      return t(
        `Alarm set for ${parsed.entities.time}. I will notify you.`,
        `${parsed.entities.time} ka alarm laga diya, sir.`,
        `${parsed.entities.time} का अलार्म लगा दिया।`
      );
    case "open_settings":
      return t(`Opening Settings.`, `Settings khol रहा hun.`, `सेटिंग्स खोल रहा हूँ।`);
    case "type_text":
      return t(
        `Typed: "${parsed.entities.text}". Please verify on screen.`,
        `"${parsed.entities.text}" type kar diya. Screen par verify kar lo.`,
        `टाइप कर दिया।`
      );
    case "phone_call":
      return t(
        `Ready to call ${parsed.entities.contact}. Please confirm to place the call.`,
        `${parsed.entities.contact} ko call karne ke liye ready hun. Confirm karo to call laga dun.`,
        `कॉल के लिए तैयार हूँ।`
      );
    case "whatsapp_message":
      return t(
        `Draft ready for ${parsed.entities.contact}. Please confirm before I send — I never send silently.`,
        `${parsed.entities.contact} ke liye draft ready hai. Confirm karo tabhi bhejunga.`,
        `ड्राफ्ट तैयार है। कन्फर्म करें।`
      );
    case "conversation": {
      const lower = input.toLowerCase();
      if (/who are you|tum kaun|aap kaun|your name|naam/.test(lower))
        return t(
          "I am JARVIS — your personal AI assistant. I work online with your configured provider, and offline with on-device intelligence. How can I help?",
          "Main JARVIS hun — aapka personal AI assistant. Online provider se ya offline on-device mode me kaam karta hun. Bataiye, kya karun?",
          "मैं JARVIS हूँ — आपका व्यक्तिगत AI सहायक।"
        );
      if (/thank|shukriya|dhanyavad/.test(lower))
        return t(
          "Always at your service, sir.",
          "Hamesha aapki seva me, sir.",
          "हमेशा आपकी सेवा में।"
        );
      if (/time|samay|baje/.test(lower) && lower.length < 30)
        return t(
          `The current time is ${new Date().toLocaleTimeString()}.`,
          `Abhi samay hai ${new Date().toLocaleTimeString()}.`,
          `अभी समय है ${new Date().toLocaleTimeString()}।`
        );
      if (/offline|internet/.test(lower))
        return t(
          "I am running in offline mode on this device. Basic automation, history and local reasoning still work. Connect internet or configure a provider for full online intelligence.",
          "Main abhi offline mode me hun. Basic automation aur history kaam karega. Full intelligence ke liye internet ya provider configure karo.",
          "मैं अभी ऑफ़लाइन मोड में हूँ।"
        );
      return t(
        "Understood. I am in offline mode with local intelligence — I can open apps, search, set alarms, control volume and draft WhatsApp messages. Connect an online provider for deeper reasoning.",
        "Samajh gaya. Main offline local intelligence par hun — apps kholna, search, alarm, volume aur WhatsApp draft kar sakta hun. Deep reasoning ke liye online provider configure karo.",
        "समझ गया। मैं ऑफ़लाइन मोड में हूँ।"
      );
    }
    default:
      return t(
        "I did not fully understand. Could you rephrase?",
        "Main poori tarah samjha nahi. Phir se bolo?",
        "मैं पूरी तरह समझा नहीं। फिर से बोलें?"
      );
  }
}

export const DEFAULT_QUICK_ACTIONS = [
  { actionKey: "whatsapp", label: "WhatsApp", icon: "message" },
  { actionKey: "youtube", label: "YouTube", icon: "play" },
  { actionKey: "chrome", label: "Chrome", icon: "globe" },
  { actionKey: "websearch", label: "Web Search", icon: "search" },
  { actionKey: "call", label: "Call", icon: "phone" },
  { actionKey: "message", label: "Message", icon: "chat" },
  { actionKey: "alarm", label: "Alarm", icon: "clock" },
  { actionKey: "settings", label: "Settings", icon: "gear" },
  { actionKey: "voice", label: "Voice Chat", icon: "mic" },
  { actionKey: "custom", label: "Custom", icon: "zap" },
];

export const OFFLINE_LLM_CATALOG = [
  {
    name: "JARVIS Nano 0.5B (Q4)",
    description: "Ultra-light on-device chat + commands. Fast on mid-range phones.",
    sizeMb: 380,
    downloadUrl: "https://huggingface.co/Qwen/Qwen2-0.5B-Instruct-GGUF",
  },
  {
    name: "JARVIS Mini 1.1B (Q4)",
    description: "Balanced offline reasoning for follow-ups and planning.",
    sizeMb: 720,
    downloadUrl: "https://huggingface.co/TinyLlama/TinyLlama-1.1B-Chat-v1.0-GGUF",
  },
  {
    name: "JARVIS Phi Compact 3.8B (Q4)",
    description: "Strongest offline reasoning. Needs 4GB+ RAM.",
    sizeMb: 2300,
    downloadUrl: "https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf",
  },
];

export const VOICE_CATALOG = [
  {
    name: "Vosk Small EN (50MB)",
    description: "Offline English speech recognition (Vosk).",
    sizeMb: 50,
    downloadUrl: "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
  },
  {
    name: "Vosk Small HI (50MB)",
    description: "Offline Hindi speech recognition (Vosk).",
    sizeMb: 50,
    downloadUrl: "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip",
  },
  {
    name: "Piper Voice EN (60MB)",
    description: "Offline neural TTS voice, natural quality.",
    sizeMb: 60,
    downloadUrl: "https://github.com/rhasspy/piper",
  },
];
